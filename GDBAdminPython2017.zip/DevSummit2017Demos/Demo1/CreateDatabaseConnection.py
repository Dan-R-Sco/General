# Demo 1: Create Database Connection File

# If running outside of the Python window, uncomment the import
#import arcpy

#Create the connection file
arcpy.CreateDatabaseConnection_management(r'C:\presentations\DevSummit2016\Demos\Demo1',
                                          'Demo1',
                                          "SQL_SERVER",
                                          'jpenney',
                                          "OPERATING_SYSTEM_AUTH",
                                          '', '',
                                          "SAVE_USERNAME",
                                          "Demo1")
